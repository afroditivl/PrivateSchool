package projectpartb;

import java.util.*;

public class MainClass {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        Method.welcome(scanner);
        scanner.close();
        
    }
}
